#!/bin/bash

java -Xmx4g -jar eSalsaVisualization.jar $@ 
